<?php

include_once 'Autoloader/Autoloader.php';

// antcloud sdk configuration
define('ANTCLOUD_SDK_VERSION', 'PHP-SDK-1.0.0');